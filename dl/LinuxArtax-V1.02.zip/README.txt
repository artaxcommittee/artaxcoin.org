
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMhyyyhMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMN/d:---yMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMM/ +h----hMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMh   yy---:dMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMN`  `NMo---:mMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMM/   sMMM+---/NMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMh   -MMMMN/---/NMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMN`   dMMMMMm:---+MMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMh///sMMMMMMMd:---oMMMMMMMMMMMMMMM
MMMMMMMMdyo//::::::::::::::::::----yMMMMMMMMMMMMMM
MMMMMMy:----------------------------hMMMMMMMMMMMMM
MMMMMo-----/ossssssssssssssssssssssssNMMMMMMMMMMMM
MMMMm----:mMMMd````dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMN:---:hMMN.   /MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMy-----:d+   `m+++++++++++++++++++++mMMMMMMMMM
MMMMMMmo:--+d    ys---------------------/NMMMMMMMM
MMMMMMMMNdym.   :N+++++++++++++++++++++++sMMMMMMMM
MMMMMMMMMMM+   `mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMh    oMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMo///+MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM


ArtaxCore Wallet  1.0.0.2
=====================

http://www.artax.one
http://www.artax.online

Copyright (c) 2009-2014 Bitcoin Developers
Copyright (c) 2016-2017 Artax Development Team


Intro
------
The ARTAX network is secured through Staking and Backend Encryption Cache Persistence(ECP). Artax uses incentivized Masternodes for services such as Instant transactions and Governance. 
Each node requires 3000 ARTX as collateral. They receive 90% block rewards rewards. 20% going to stakers. ARTAX is the ying to BoxyCoin's yang.

Artax is a node-scaled version of Bitcoin using scrypt as a proof-of-work algorithm.

65 second block targets
100 million total coins
2500 coins to stake a node
Stake age 10hours
20 coins per block
BoxyCoin blockchain integration
10 minute Re-target
For more information, as well as an immediately useable, binary version of the Artax client sofware, see http://www.artax.one


Setup
-----
Unpack the files into a directory and run ArtaxCore.exe.
ArtaxCore is the original Artax client and it builds the backbone of the network.
However, it downloads and stores the entire history of Artax transactions;
depending on the speed of your computer and network connection, the synchronization
process can take anywhere from a few hours to a day or more.


What is different about Artax?
---------------------------------
ARTAX uses high volume scrypt hashing to protect blockchain network. The idea of ARTAX is to re-purpose high-volume hashes 
in both ARTAX and BoxyCoin to integrate encryption cache persistence and node streamlining through one spectrum. ARTAX has 
the allowances for both I2P and Tor Integration. The ARTAX Encryption Cache Technology that is being developed, is being deployed through BoxyCoin - The sister coin to ARTAX. Once refined, ARTAX will integrate.

Source Code: http://www.github.com/Artax-Project/Artax.git 
Discord: https://discord.gg/ratBwks 
Facebook: http://www.facebook.com/artaxtech
Artax Website: http://www.artax.one 
Reddit: http://www.reddit.com/r/Artax

License
-------
ArtaxCore is released under the terms of the MIT license. ArtaxCore software is experimental. See COPYING for more information or see http://opensource.org/licenses/MIT.
